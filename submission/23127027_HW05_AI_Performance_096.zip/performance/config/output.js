// REVIEWED OUTPUT METADATA — official real-data reports now exist.
// This unimported metadata does not implement or claim JTL conversion.

export const OUTPUT_PROPOSALS = Object.freeze({
  load: Object.freeze({
    primary: 'end-of-test aggregate/custom summary',
    canonicalRaw: 'native k6 granular JSON',
    finalCompliance: 'K6_EQUIVALENT_OUTPUT_HUMAN_APPROVED',
  }),
  stress: Object.freeze({
    primary: 'native k6 CSV time series',
    canonicalRaw: 'native k6 granular JSON',
    finalCompliance: 'K6_EQUIVALENT_OUTPUT_HUMAN_APPROVED',
  }),
  spike: Object.freeze({
    primary: 'k6 web-dashboard time-series HTML',
    canonicalRaw: 'native k6 granular JSON',
    finalCompliance: 'K6_EQUIVALENT_OUTPUT_HUMAN_APPROVED',
  }),
});
